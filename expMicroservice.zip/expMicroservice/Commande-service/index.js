
const express = require("express");
const app = express();
const PORT = process.env.PORT_ONE || 4001;
const mongoose = require("mongoose");
const Commande = require("./Commande");
const axios = require('axios');

app.use(express.json());

async function connectToDatabase() {
    try {
        await mongoose.connect("mongodb://localhost/commande-service");
        console.log('Commande-Service DB Connected');
    } catch (error) {
        console.error('Error connecting to the database:', error);
    }
}

connectToDatabase();

function prixTotal(produits) {
    let total = 0;
    for (let t = 0; t < produits.length; ++t) {
        total += produits[t].prix;
    }
    console.log("prix total :" + total);
    return total;
}

async function httpRequest(ids) {
    try {
        const response = await axios.post("http://localhost:4000/produit/acheter", { ids });
        return prixTotal(response.data);
    } catch (error) {
        console.error(error);
    }
}

app.post("/commande/ajouter", async (req, res) => {
    const { ids, email_utilisateur } = req.body;
    try {
        const total = await httpRequest(ids);
        const newCommande = new Commande({
            produits: ids,
            email_utilisateur,
            prix_total: total
        });
        const savedCommande = await newCommande.save();
        res.status(201).json(savedCommande);
    } catch (error) {
        res.status(400).json({ error });
    }
});

app.listen(PORT, () => {
    console.log(`Commande-Service at ${PORT}`);
});
